package tj.gallery.secret;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.util.Size;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final int BG = 0xFF0F1012, CARD = 0xFF1B1C20, INK = 0xFFF2F2F0, MUTE = 0xFF9A9AA2,
            ACC = 0xFFFF5A4E, HID = 0xFF7C5CFF;
    static final int REQ_PERM = 7, REQ_HIDE = 11, REQ_DEL = 12;
    static final int A_FAV = 0, A_USER = 1, A_BUCKET = 2, A_ADD = 3;

    static class Item {
        String key;
        boolean vault, video;
        long id;
        Uri uri;
        File file;
        String name0 = "", bucket = "", mime = "";
        long date, dur;
    }

    static class AlbumRef {
        int type;
        int index;
        String name;
        int count;
        Item cover;
    }

    static class Holder {
        ImageView img;
        TextView badge, fav, title, count;
        String key;
    }

    static class SquareFrame extends FrameLayout {
        SquareFrame(Context c) { super(c); }

        @Override
        protected void onMeasure(int w, int h) { super.onMeasure(w, w); }
    }

    SharedPreferences prefs;
    final List<Item> device = new ArrayList<>();
    final List<Item> vault = new ArrayList<>();
    final List<Item> shown = new ArrayList<>();
    final List<AlbumRef> albumCards = new ArrayList<>();
    boolean hiddenMode = false, goSettings = false;
    int tab = 0;
    AlbumRef curAlbum = null;

    LinearLayout searchRow, hidBar, tabsRow;
    EditText search;
    TextView title, info, empty;
    Button backBtn, menuBtn, tabPhotos, tabAlbums, permBtn;
    GridView grid;
    ItemAdapter itemAdapter;
    AlbumAdapter albumAdapter;

    final ExecutorService loader = Executors.newSingleThreadExecutor();
    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final Handler ui = new Handler(Looper.getMainLooper());
    LruCache<String, Bitmap> cache;

    // pending operations
    List<Item> pendHide;
    List<JSONObject> pendMeta;
    List<File> pendFiles;
    List<Item> pendDelete;

    // ================= helpers =================

    int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    Button btn(String t, int bg, int fg) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 12));
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setStateListAnimator(null);
        return b;
    }

    LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    static String fmtDur(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    // ================= lifecycle =================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("g", MODE_PRIVATE);
        int mem = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8);
        cache = new LruCache<String, Bitmap>(mem) {
            @Override
            protected int sizeOf(String k, Bitmap v) { return v.getByteCount() / 1024; }
        };
        buildUi();
        loadVault();
        if (!prefs.contains("code")) askCode(true);
        else checkPermAndLoad();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (hasPerm()) loadDevice();
        else render();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (hiddenMode && pendHide == null && pendDelete == null) {
            closeViewer();
            hiddenMode = false;
            curAlbum = null;
            render();
        }
    }

    @Override
    public void onBackPressed() {
        if (curAlbum != null) { curAlbum = null; render(); return; }
        if (hiddenMode) { hiddenMode = false; tab = 0; render(); return; }
        super.onBackPressed();
    }

    // ================= UI =================

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(10), dp(12), 0);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        backBtn = btn("←", CARD, INK);
        titleRow.addView(backBtn, lp(dp(46), dp(44), 0));
        title = new TextView(this);
        title.setTextColor(INK);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(dp(8), dp(4), dp(8), dp(4));
        titleRow.addView(title, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        menuBtn = btn("⋯", CARD, INK);
        titleRow.addView(menuBtn, lp(dp(46), dp(44), 0));
        root.addView(titleRow);

        searchRow = new LinearLayout(this);
        searchRow.setPadding(0, dp(8), 0, 0);
        search = new EditText(this);
        search.setHint("Поиск по названию");
        search.setHintTextColor(MUTE);
        search.setTextColor(INK);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(round(CARD, 12));
        search.setPadding(dp(14), 0, dp(14), 0);
        searchRow.addView(search, lp(0, dp(46), 1));
        Button go = btn("Поиск", ACC, Color.WHITE);
        LinearLayout.LayoutParams gp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46), 0);
        gp.leftMargin = dp(8);
        searchRow.addView(go, gp);
        root.addView(searchRow);

        hidBar = new LinearLayout(this);
        hidBar.setGravity(Gravity.CENTER_VERTICAL);
        hidBar.setBackground(round(HID, 12));
        hidBar.setPadding(dp(14), dp(5), dp(5), dp(5));
        LinearLayout.LayoutParams hbp = lp(-1, ViewGroup.LayoutParams.WRAP_CONTENT, 0);
        hbp.topMargin = dp(8);
        TextView ht = new TextView(this);
        ht.setText("Скрытый режим");
        ht.setTextColor(Color.WHITE);
        ht.setTypeface(Typeface.DEFAULT_BOLD);
        hidBar.addView(ht, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button chg = btn("Сменить код", 0x33FFFFFF, Color.WHITE);
        chg.setTextSize(13);
        hidBar.addView(chg, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38), 0));
        Button exit = btn("Выйти", 0x33FFFFFF, Color.WHITE);
        exit.setTextSize(13);
        LinearLayout.LayoutParams ep = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38), 0);
        ep.leftMargin = dp(6);
        hidBar.addView(exit, ep);
        root.addView(hidBar, hbp);

        tabsRow = new LinearLayout(this);
        tabsRow.setPadding(0, dp(8), 0, 0);
        tabPhotos = btn("Фото", CARD, INK);
        tabAlbums = btn("Альбомы", CARD, INK);
        tabsRow.addView(tabPhotos, lp(0, dp(42), 1));
        LinearLayout.LayoutParams tp = lp(0, dp(42), 1);
        tp.leftMargin = dp(8);
        tabsRow.addView(tabAlbums, tp);
        root.addView(tabsRow);

        info = new TextView(this);
        info.setTextColor(MUTE);
        info.setTextSize(13);
        info.setPadding(dp(4), dp(8), 0, dp(6));
        root.addView(info);

        FrameLayout content = new FrameLayout(this);
        grid = new GridView(this);
        grid.setHorizontalSpacing(dp(3));
        grid.setVerticalSpacing(dp(3));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setPadding(0, 0, 0, dp(24));
        itemAdapter = new ItemAdapter();
        albumAdapter = new AlbumAdapter();
        content.addView(grid, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout emptyBox = new LinearLayout(this);
        emptyBox.setOrientation(LinearLayout.VERTICAL);
        emptyBox.setGravity(Gravity.CENTER);
        empty = new TextView(this);
        empty.setTextColor(MUTE);
        empty.setTextSize(16);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(24), 0, dp(24), dp(16));
        emptyBox.addView(empty);
        permBtn = btn("Дать доступ", ACC, Color.WHITE);
        permBtn.setVisibility(View.GONE);
        emptyBox.addView(permBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), 0));
        FrameLayout.LayoutParams ebp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        content.addView(emptyBox, ebp);
        root.addView(content, lp(-1, 0, 1));

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            public void onTextChanged(CharSequence s, int a, int c, int d) { }
            public void afterTextChanged(Editable s) { if (!hiddenMode) render(); }
        });
        search.setOnEditorActionListener((v, a, e) -> { doSearch(); return true; });
        go.setOnClickListener(v -> doSearch());
        exit.setOnClickListener(v -> { hiddenMode = false; curAlbum = null; tab = 0; render(); });
        chg.setOnClickListener(v -> askCode(false));
        backBtn.setOnClickListener(v -> { curAlbum = null; render(); });
        menuBtn.setOnClickListener(v -> albumMenu());
        tabPhotos.setOnClickListener(v -> { tab = 0; curAlbum = null; render(); });
        tabAlbums.setOnClickListener(v -> { tab = 1; curAlbum = null; render(); });
        permBtn.setOnClickListener(v -> {
            if (goSettings) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null)));
            } else {
                requestPermissions(perms(), REQ_PERM);
            }
        });
        grid.setOnItemClickListener((p, v, pos, id) -> {
            if (showingAlbums()) {
                if (pos >= albumCards.size()) return;
                AlbumRef r = albumCards.get(pos);
                if (r.type == A_ADD) newAlbum(null);
                else { curAlbum = r; render(); }
            } else if (pos < shown.size()) {
                openViewer(new ArrayList<>(shown), pos);
            }
        });
    }

    boolean showingAlbums() { return tab == 1 && curAlbum == null; }

    void render() {
        boolean perm = hasPerm();
        title.setText(curAlbum != null ? curAlbum.name : (hiddenMode ? "Скрытые" : "Галерея"));
        backBtn.setVisibility(curAlbum != null ? View.VISIBLE : View.GONE);
        menuBtn.setVisibility(curAlbum != null && curAlbum.type == A_USER ? View.VISIBLE : View.GONE);
        searchRow.setVisibility(!hiddenMode && tab == 0 && curAlbum == null ? View.VISIBLE : View.GONE);
        hidBar.setVisibility(hiddenMode ? View.VISIBLE : View.GONE);
        tabsRow.setVisibility(curAlbum == null ? View.VISIBLE : View.GONE);
        styleTab(tabPhotos, tab == 0);
        styleTab(tabAlbums, tab == 1);
        if (hiddenMode) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        permBtn.setVisibility(View.GONE);

        if (!hiddenMode && !perm) {
            shown.clear();
            albumCards.clear();
            grid.setAdapter(itemAdapter);
            info.setText("");
            empty.setText("Разрешите доступ к фото и видео, чтобы галерея их показала.");
            empty.setVisibility(View.VISIBLE);
            permBtn.setText(goSettings ? "Открыть настройки" : "Дать доступ");
            permBtn.setVisibility(View.VISIBLE);
            return;
        }

        if (showingAlbums()) {
            buildAlbumCards();
            grid.setNumColumns(2);
            grid.setVerticalSpacing(dp(12));
            if (grid.getAdapter() != albumAdapter) grid.setAdapter(albumAdapter);
            else albumAdapter.notifyDataSetChanged();
            info.setText("Альбомов: " + (albumCards.size() - 1));
            empty.setVisibility(View.GONE);
            return;
        }

        List<Item> src = curAlbum != null ? albumItems(curAlbum) : modeItems();
        String q = (!hiddenMode && curAlbum == null) ? search.getText().toString().trim().toLowerCase() : "";
        shown.clear();
        for (Item it : src) {
            if (q.isEmpty() || name(it).toLowerCase().contains(q)) shown.add(it);
        }
        grid.setNumColumns(3);
        grid.setVerticalSpacing(dp(3));
        if (grid.getAdapter() != itemAdapter) grid.setAdapter(itemAdapter);
        else itemAdapter.notifyDataSetChanged();
        info.setText(src.isEmpty() ? "" : (q.isEmpty() ? "Всего: " + src.size() : "Найдено: " + shown.size()));
        if (shown.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            if (!q.isEmpty()) empty.setText("Ничего не найдено");
            else if (curAlbum != null) empty.setText("В этом альбоме пока пусто");
            else if (hiddenMode) empty.setText("Здесь пока пусто.\nЧтобы скрыть фото или видео, откройте его, нажмите «Имя» и введите код.");
            else empty.setText("Фото и видео не найдены");
        } else {
            empty.setVisibility(View.GONE);
        }
    }

    void styleTab(Button b, boolean on) {
        b.setBackground(round(on ? (hiddenMode ? HID : ACC) : CARD, 12));
        b.setTextColor(on ? Color.WHITE : INK);
    }

    // ================= code =================

    static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("gal-v1:" + s.trim()).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.trim().hashCode());
        }
    }

    boolean isCode(String s) {
        if (s == null || s.trim().isEmpty()) return false;
        return hash(s).equals(prefs.getString("code", null));
    }

    EditText field(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    void askCode(boolean first) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText a = field(first ? "Код" : "Новый код", true);
        EditText b = field("Повторите код", true);
        TextView err = new TextView(this);
        err.setTextColor(ACC);
        err.setPadding(0, dp(4), 0, 0);
        box.addView(a);
        box.addView(b);
        box.addView(err);
        AlertDialog.Builder bld = dlg()
                .setTitle(first ? "Придумайте код" : "Сменить код")
                .setView(box)
                .setPositiveButton("Сохранить", null);
        if (first) {
            bld.setMessage("Введите его дважды и запомните.");
            bld.setCancelable(false);
        } else {
            bld.setNegativeButton("Отмена", null);
        }
        AlertDialog d = bld.create();
        if (first) d.setCanceledOnTouchOutside(false);
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String s1 = a.getText().toString(), s2 = b.getText().toString();
            if (s1.trim().length() < 3) { err.setText("Минимум 3 символа"); return; }
            if (!s1.equals(s2)) { err.setText("Коды не совпадают"); return; }
            prefs.edit().putString("code", hash(s1)).apply();
            d.dismiss();
            if (first) checkPermAndLoad();
            else toast("Сохранено");
        }));
        d.show();
    }

    void doSearch() {
        String v = search.getText().toString();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
        search.clearFocus();
        if (isCode(v)) {
            hiddenMode = true;
            tab = 0;
            curAlbum = null;
            search.setText("");
        }
        render();
    }

    // ================= permissions =================

    String[] perms() {
        if (Build.VERSION.SDK_INT >= 33)
            return new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"};
        if (Build.VERSION.SDK_INT <= 29)
            return new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
        return new String[]{"android.permission.READ_EXTERNAL_STORAGE"};
    }

    boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    boolean hasPerm() {
        if (Build.VERSION.SDK_INT >= 33) {
            return granted("android.permission.READ_MEDIA_IMAGES") || granted("android.permission.READ_MEDIA_VIDEO")
                    || (Build.VERSION.SDK_INT >= 34 && granted("android.permission.READ_MEDIA_VISUAL_USER_SELECTED"));
        }
        return granted("android.permission.READ_EXTERNAL_STORAGE");
    }

    void checkPermAndLoad() {
        if (hasPerm()) loadDevice();
        else {
            render();
            requestPermissions(perms(), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (hasPerm()) loadDevice();
        else {
            goSettings = !shouldShowRequestPermissionRationale(perms()[0]);
            render();
        }
    }

    // ================= data =================

    File vaultDir() {
        File d = new File(getFilesDir(), "vault");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    JSONArray vaultMeta() {
        try { return new JSONArray(prefs.getString("vault", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void saveVaultMeta(JSONArray a) { prefs.edit().putString("vault", a.toString()).apply(); }

    void loadVault() {
        vault.clear();
        JSONArray a = vaultMeta();
        File dir = vaultDir();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            File f = new File(dir, o.optString("file"));
            if (!f.exists()) continue;
            Item it = new Item();
            it.vault = true;
            it.file = f;
            it.uri = Uri.fromFile(f);
            it.key = "f" + o.optString("file");
            it.video = o.optBoolean("video");
            it.name0 = o.optString("name");
            it.mime = o.optString("mime");
            it.date = o.optLong("date");
            it.dur = o.optLong("dur");
            vault.add(it);
        }
        Collections.sort(vault, (x, y) -> Long.compare(y.date, x.date));
    }

    void loadDevice() {
        loader.execute(() -> {
            List<Item> list = new ArrayList<>();
            query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, list);
            query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, list);
            Collections.sort(list, (x, y) -> Long.compare(y.date, x.date));
            ui.post(() -> {
                device.clear();
                device.addAll(list);
                render();
            });
        });
    }

    void query(Uri table, boolean video, List<Item> out) {
        String[] proj = video
                ? new String[]{"_id", "_display_name", "bucket_display_name", "date_added", "mime_type", "duration"}
                : new String[]{"_id", "_display_name", "bucket_display_name", "date_added", "mime_type"};
        try (Cursor c = getContentResolver().query(table, proj, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                Item it = new Item();
                it.id = c.getLong(0);
                String f = c.getString(1);
                if (f == null) f = "";
                int dot = f.lastIndexOf('.');
                it.name0 = dot > 0 ? f.substring(0, dot) : f;
                it.bucket = c.getString(2);
                if (it.bucket == null) it.bucket = "Другое";
                it.date = c.getLong(3);
                it.mime = c.getString(4);
                if (it.mime == null) it.mime = video ? "video/mp4" : "image/jpeg";
                it.video = video;
                if (video) it.dur = c.getLong(5);
                it.uri = ContentUris.withAppendedId(table, it.id);
                it.key = (video ? "v" : "i") + it.id;
                out.add(it);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    List<Item> modeItems() { return hiddenMode ? vault : device; }

    String name(Item it) {
        String n = prefs.getString("n_" + it.key, null);
        return n != null ? n : it.name0;
    }

    Set<String> favs() { return new HashSet<>(prefs.getStringSet("fav", new HashSet<>())); }

    boolean isFav(Item it) { return favs().contains(it.key); }

    void toggleFav(Item it) {
        Set<String> s = favs();
        if (!s.remove(it.key)) s.add(it.key);
        prefs.edit().putStringSet("fav", s).apply();
    }

    String albumsKey() { return hiddenMode ? "alb_h" : "alb_n"; }

    JSONArray albums() {
        try { return new JSONArray(prefs.getString(albumsKey(), "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void saveAlbums(JSONArray a) { prefs.edit().putString(albumsKey(), a.toString()).apply(); }

    boolean inAlbum(JSONObject al, String key) {
        JSONArray k = al.optJSONArray("items");
        if (k == null) return false;
        for (int i = 0; i < k.length(); i++) if (key.equals(k.optString(i))) return true;
        return false;
    }

    void toggleInAlbum(int index, Item it) {
        try {
            JSONArray a = albums();
            JSONObject al = a.getJSONObject(index);
            JSONArray k = al.optJSONArray("items");
            if (k == null) k = new JSONArray();
            JSONArray nk = new JSONArray();
            boolean found = false;
            for (int i = 0; i < k.length(); i++) {
                if (it.key.equals(k.optString(i))) found = true;
                else nk.put(k.optString(i));
            }
            if (!found) nk.put(it.key);
            al.put("items", nk);
            saveAlbums(a);
            toast(found ? "Убрано из альбома" : "Добавлено в «" + al.optString("name") + "»");
        } catch (Exception e) {
            toast("Ошибка");
        }
    }

    /** Remove a key from favourites, names and all albums (both modes). */
    void forgetKey(String key) {
        Set<String> s = favs();
        s.remove(key);
        SharedPreferences.Editor ed = prefs.edit().putStringSet("fav", s).remove("n_" + key);
        for (String ak : new String[]{"alb_n", "alb_h"}) {
            try {
                JSONArray a = new JSONArray(prefs.getString(ak, "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject al = a.getJSONObject(i);
                    JSONArray k = al.optJSONArray("items");
                    if (k == null) continue;
                    JSONArray nk = new JSONArray();
                    for (int j = 0; j < k.length(); j++) if (!key.equals(k.optString(j))) nk.put(k.optString(j));
                    al.put("items", nk);
                }
                ed.putString(ak, a.toString());
            } catch (Exception e) {
                // ignore
            }
        }
        ed.apply();
    }

    List<Item> albumItems(AlbumRef r) {
        List<Item> out = new ArrayList<>();
        List<Item> src = modeItems();
        if (r.type == A_FAV) {
            Set<String> f = favs();
            for (Item it : src) if (f.contains(it.key)) out.add(it);
        } else if (r.type == A_BUCKET) {
            for (Item it : src) if (r.name.equals(it.bucket)) out.add(it);
        } else if (r.type == A_USER) {
            JSONObject al = albums().optJSONObject(r.index);
            if (al != null) {
                Map<String, Item> map = new HashMap<>();
                for (Item it : src) map.put(it.key, it);
                JSONArray k = al.optJSONArray("items");
                if (k != null) {
                    for (int i = k.length() - 1; i >= 0; i--) {
                        Item it = map.get(k.optString(i));
                        if (it != null) out.add(it);
                    }
                }
                r.name = al.optString("name");
            }
        }
        return out;
    }

    void buildAlbumCards() {
        albumCards.clear();
        AlbumRef fav = new AlbumRef();
        fav.type = A_FAV;
        fav.name = "♥ Избранное";
        List<Item> fl = albumItems(fav);
        fav.count = fl.size();
        fav.cover = fl.isEmpty() ? null : fl.get(0);
        albumCards.add(fav);
        JSONArray a = albums();
        for (int i = 0; i < a.length(); i++) {
            AlbumRef r = new AlbumRef();
            r.type = A_USER;
            r.index = i;
            List<Item> l = albumItems(r);
            r.count = l.size();
            r.cover = l.isEmpty() ? null : l.get(0);
            albumCards.add(r);
        }
        if (!hiddenMode) {
            LinkedHashMap<String, AlbumRef> buckets = new LinkedHashMap<>();
            for (Item it : device) {
                AlbumRef r = buckets.get(it.bucket);
                if (r == null) {
                    r = new AlbumRef();
                    r.type = A_BUCKET;
                    r.name = it.bucket;
                    r.cover = it;
                    buckets.put(it.bucket, r);
                }
                r.count++;
            }
            albumCards.addAll(buckets.values());
        }
        AlbumRef add = new AlbumRef();
        add.type = A_ADD;
        add.name = "Новый альбом";
        albumCards.add(add);
    }

    void newAlbum(Item addItem) {
        EditText e = field("Название альбома", false);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        dlg().setTitle("Новый альбом").setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Создать", (x, w) -> {
                    String n = e.getText().toString().trim();
                    if (n.isEmpty() || isCode(n)) return;
                    try {
                        JSONArray a = albums();
                        JSONObject o = new JSONObject();
                        o.put("name", n);
                        JSONArray k = new JSONArray();
                        if (addItem != null) k.put(addItem.key);
                        o.put("items", k);
                        a.put(o);
                        saveAlbums(a);
                        if (addItem != null) toast("Добавлено в «" + n + "»");
                    } catch (Exception ex) {
                        toast("Ошибка");
                    }
                    render();
                }).show();
    }

    void albumMenu() {
        if (curAlbum == null || curAlbum.type != A_USER) return;
        final int idx = curAlbum.index;
        dlg().setTitle(curAlbum.name)
                .setItems(new String[]{"Переименовать альбом", "Удалить альбом"}, (x, which) -> {
                    if (which == 0) {
                        EditText e = field("Название", false);
                        e.setText(curAlbum.name);
                        FrameLayout box = new FrameLayout(this);
                        box.setPadding(dp(20), dp(8), dp(20), 0);
                        box.addView(e);
                        dlg().setTitle("Переименовать").setView(box).setNegativeButton("Отмена", null)
                                .setPositiveButton("Сохранить", (y, w) -> {
                                    String n = e.getText().toString().trim();
                                    if (n.isEmpty() || isCode(n)) return;
                                    try {
                                        JSONArray a = albums();
                                        a.getJSONObject(idx).put("name", n);
                                        saveAlbums(a);
                                        if (curAlbum != null) curAlbum.name = n;
                                    } catch (Exception ex) {
                                        toast("Ошибка");
                                    }
                                    render();
                                }).show();
                    } else {
                        dlg().setTitle("Удалить альбом?")
                                .setMessage("Сами фото и видео останутся в галерее.")
                                .setNegativeButton("Отмена", null)
                                .setPositiveButton("Удалить", (y, w) -> {
                                    JSONArray a = albums();
                                    JSONArray na = new JSONArray();
                                    for (int i = 0; i < a.length(); i++) if (i != idx) na.put(a.opt(i));
                                    saveAlbums(na);
                                    curAlbum = null;
                                    render();
                                }).show();
                    }
                }).show();
    }

    // ================= thumbnails =================

    Bitmap thumb(Item it) {
        try {
            if (it.vault) {
                if (Build.VERSION.SDK_INT >= 29) {
                    return it.video ? ThumbnailUtils.createVideoThumbnail(it.file, new Size(320, 320), null)
                            : ThumbnailUtils.createImageThumbnail(it.file, new Size(320, 320), null);
                }
                if (it.video)
                    return ThumbnailUtils.createVideoThumbnail(it.file.getAbsolutePath(), MediaStore.Images.Thumbnails.MINI_KIND);
                return decodeFile(it.file, 320);
            }
            if (Build.VERSION.SDK_INT >= 29)
                return getContentResolver().loadThumbnail(it.uri, new Size(320, 320), null);
            if (it.video)
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), it.id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            return MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), it.id,
                    MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Throwable e) {
            return null;
        }
    }

    Bitmap decodeFile(File f, int max) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / sample > max * 2) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
    }

    Bitmap full(Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.Source src = it.vault ? ImageDecoder.createSource(it.file)
                        : ImageDecoder.createSource(getContentResolver(), it.uri);
                return ImageDecoder.decodeBitmap(src, (dec, inf, s) -> {
                    int w = inf.getSize().getWidth(), hh = inf.getSize().getHeight();
                    int m = Math.max(w, hh);
                    if (m > 2560) {
                        float r = 2560f / m;
                        dec.setTargetSize(Math.max(1, Math.round(w * r)), Math.max(1, Math.round(hh * r)));
                    }
                });
            }
            if (it.vault) return decodeFile(it.file, 1280);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 2560) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
                return BitmapFactory.decodeStream(in, null, o2);
            }
        } catch (Throwable e) {
            return thumb(it);
        }
    }

    void bindThumb(Holder h, Item it) {
        final String k = it.key;
        h.key = k;
        Bitmap bm = cache.get(k);
        if (bm != null) {
            h.img.setImageBitmap(bm);
            return;
        }
        h.img.setImageDrawable(null);
        final Holder fh = h;
        pool.execute(() -> {
            if (!k.equals(fh.key)) return;
            Bitmap t = thumb(it);
            if (t != null) cache.put(k, t);
            ui.post(() -> { if (k.equals(fh.key) && t != null) fh.img.setImageBitmap(t); });
        });
    }

    // ================= adapters =================

    class ItemAdapter extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int p) { return shown.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int pos, View cv, ViewGroup parent) {
            Holder h;
            if (cv == null || !(cv.getTag() instanceof Holder) || ((Holder) cv.getTag()).title != null) {
                SquareFrame f = new SquareFrame(MainActivity.this);
                f.setBackground(round(CARD, 4));
                f.setClipToOutline(true);
                h = new Holder();
                h.img = new ImageView(MainActivity.this);
                h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                f.addView(h.img, new FrameLayout.LayoutParams(-1, -1));
                h.badge = new TextView(MainActivity.this);
                h.badge.setTextColor(Color.WHITE);
                h.badge.setTextSize(11);
                h.badge.setTypeface(Typeface.DEFAULT_BOLD);
                h.badge.setShadowLayer(4, 0, 0, Color.BLACK);
                h.badge.setPadding(dp(5), dp(3), dp(5), dp(3));
                f.addView(h.badge, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
                h.fav = new TextView(MainActivity.this);
                h.fav.setText("♥");
                h.fav.setTextColor(Color.WHITE);
                h.fav.setTextSize(13);
                h.fav.setShadowLayer(4, 0, 0, Color.BLACK);
                h.fav.setPadding(dp(5), dp(3), dp(5), dp(3));
                f.addView(h.fav, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START));
                f.setTag(h);
                cv = f;
            } else {
                h = (Holder) cv.getTag();
            }
            Item it = shown.get(pos);
            h.badge.setText(it.video ? "▶ " + fmtDur(it.dur) : "");
            h.badge.setVisibility(it.video ? View.VISIBLE : View.GONE);
            h.fav.setVisibility(isFav(it) ? View.VISIBLE : View.GONE);
            bindThumb(h, it);
            return cv;
        }
    }

    class AlbumAdapter extends BaseAdapter {
        public int getCount() { return albumCards.size(); }
        public Object getItem(int p) { return albumCards.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int pos, View cv, ViewGroup parent) {
            Holder h;
            if (cv == null || !(cv.getTag() instanceof Holder) || ((Holder) cv.getTag()).title == null) {
                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                SquareFrame f = new SquareFrame(MainActivity.this);
                f.setBackground(round(CARD, 14));
                f.setClipToOutline(true);
                h = new Holder();
                h.img = new ImageView(MainActivity.this);
                h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                f.addView(h.img, new FrameLayout.LayoutParams(-1, -1));
                h.badge = new TextView(MainActivity.this);
                h.badge.setTextColor(MUTE);
                h.badge.setTextSize(42);
                h.badge.setGravity(Gravity.CENTER);
                f.addView(h.badge, new FrameLayout.LayoutParams(-1, -1));
                col.addView(f, new LinearLayout.LayoutParams(-1, -2));
                h.title = new TextView(MainActivity.this);
                h.title.setTextColor(INK);
                h.title.setTextSize(15);
                h.title.setTypeface(Typeface.DEFAULT_BOLD);
                h.title.setSingleLine(true);
                h.title.setEllipsize(TextUtils.TruncateAt.END);
                h.title.setPadding(dp(2), dp(6), 0, 0);
                col.addView(h.title);
                h.count = new TextView(MainActivity.this);
                h.count.setTextColor(MUTE);
                h.count.setTextSize(13);
                h.count.setPadding(dp(2), 0, 0, 0);
                col.addView(h.count);
                col.setTag(h);
                cv = col;
            } else {
                h = (Holder) cv.getTag();
            }
            AlbumRef r = albumCards.get(pos);
            if (r.type == A_USER && r.name == null) r.name = "Альбом";
            h.title.setText(r.name);
            h.count.setText(r.type == A_ADD ? "" : String.valueOf(r.count));
            if (r.cover != null) {
                h.badge.setText("");
                bindThumb(h, r.cover);
            } else {
                h.key = null;
                h.img.setImageDrawable(null);
                h.badge.setText(r.type == A_ADD ? "+" : (r.type == A_FAV ? "♥" : "▢"));
            }
            return cv;
        }
    }

    // ================= viewer =================

    Dialog vd;
    List<Item> vList;
    int vPos;
    FrameLayout stage;
    LinearLayout vTop, vBottom, vControls;
    TextView vName, vTime;
    Button vFav, vPlay;
    SeekBar vSeek;
    VideoView curVideo;
    boolean barsOn = true;
    final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (curVideo != null && vd != null) {
                try {
                    int d = curVideo.getDuration();
                    int p = curVideo.getCurrentPosition();
                    if (d > 0) {
                        vSeek.setMax(d);
                        vSeek.setProgress(p);
                        vTime.setText(fmtDur(p) + " / " + fmtDur(d));
                    }
                    vPlay.setText(curVideo.isPlaying() ? "❚❚" : "▶");
                } catch (Exception e) {
                    // ignore
                }
                ui.postDelayed(this, 300);
            }
        }
    };

    Button vBtn(String t) {
        Button b = btn(t, 0x26FFFFFF, Color.WHITE);
        b.setTextSize(14);
        return b;
    }

    void openViewer(List<Item> list, int pos) {
        closeViewer();
        vList = list;
        vPos = pos;
        Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        vd = d;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        stage = new FrameLayout(this);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));

        vTop = new LinearLayout(this);
        vTop.setGravity(Gravity.CENTER_VERTICAL);
        vTop.setBackgroundColor(0x88000000);
        vTop.setPadding(dp(8), dp(8), dp(12), dp(8));
        Button back = vBtn("←");
        vTop.addView(back, lp(dp(48), dp(44), 0));
        vName = new TextView(this);
        vName.setTextColor(Color.WHITE);
        vName.setTextSize(16);
        vName.setTypeface(Typeface.DEFAULT_BOLD);
        vName.setSingleLine(true);
        vName.setEllipsize(TextUtils.TruncateAt.END);
        vName.setPadding(dp(12), 0, 0, 0);
        vTop.addView(vName, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(vTop, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout bottomWrap = new LinearLayout(this);
        bottomWrap.setOrientation(LinearLayout.VERTICAL);
        bottomWrap.setBackgroundColor(0x88000000);
        vControls = new LinearLayout(this);
        vControls.setGravity(Gravity.CENTER_VERTICAL);
        vControls.setPadding(dp(12), dp(6), dp(12), 0);
        vPlay = vBtn("▶");
        vControls.addView(vPlay, lp(dp(48), dp(42), 0));
        vSeek = new SeekBar(this);
        vControls.addView(vSeek, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        vTime = new TextView(this);
        vTime.setTextColor(Color.WHITE);
        vTime.setTextSize(12);
        vControls.addView(vTime);
        bottomWrap.addView(vControls);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        vBottom = new LinearLayout(this);
        vBottom.setPadding(dp(10), dp(10), dp(10), dp(14));
        hs.addView(vBottom);
        bottomWrap.addView(hs);
        vTop.setTag(bottomWrap);
        root.addView(bottomWrap, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        vFav = vBtn("♡");
        addAction(vFav);
        Button alb = vBtn("＋ Альбом");
        addAction(alb);
        Button ren = vBtn("Имя");
        addAction(ren);
        Button share = null, restore = null;
        if (hiddenMode) {
            restore = vBtn("Вернуть в галерею");
            addAction(restore);
        } else {
            share = vBtn("Отправить");
            addAction(share);
        }
        Button del = vBtn("Удалить");
        addAction(del);

        back.setOnClickListener(x -> d.dismiss());
        vFav.setOnClickListener(x -> {
            Item it = curItem();
            if (it == null) return;
            toggleFav(it);
            updateBars();
            render();
        });
        alb.setOnClickListener(x -> addToAlbum());
        ren.setOnClickListener(x -> rename());
        if (share != null) share.setOnClickListener(x -> shareCur());
        if (restore != null) restore.setOnClickListener(x -> restoreCur());
        del.setOnClickListener(x -> deleteCur());
        vPlay.setOnClickListener(x -> {
            if (curVideo == null) return;
            if (curVideo.isPlaying()) curVideo.pause(); else curVideo.start();
        });
        vSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && curVideo != null) curVideo.seekTo(p);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });

        d.setOnDismissListener(x -> {
            stopVideo();
            if (vd == d) vd = null;
        });
        d.setContentView(root);
        if (hiddenMode && d.getWindow() != null)
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        barsOn = true;
        d.show();
        showPage(0);
    }

    void addAction(Button b) {
        LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44), 0);
        p.rightMargin = dp(8);
        vBottom.addView(b, p);
    }

    Item curItem() {
        if (vList == null || vPos < 0 || vPos >= vList.size()) return null;
        return vList.get(vPos);
    }

    void closeViewer() {
        if (vd != null) {
            Dialog d = vd;
            vd = null;
            d.dismiss();
        }
    }

    void stopVideo() {
        if (curVideo != null) {
            try { curVideo.stopPlayback(); } catch (Exception e) { /* ignore */ }
            curVideo = null;
        }
        ui.removeCallbacks(ticker);
    }

    void toggleBars() {
        barsOn = !barsOn;
        vTop.setVisibility(barsOn ? View.VISIBLE : View.GONE);
        ((View) vTop.getTag()).setVisibility(barsOn ? View.VISIBLE : View.GONE);
    }

    void swipe(int dir) {
        int np = vPos + dir;
        if (vList == null || np < 0 || np >= vList.size()) return;
        vPos = np;
        showPage(dir);
    }

    void updateBars() {
        Item it = curItem();
        if (it == null) return;
        vName.setText(name(it) + "   " + (vPos + 1) + "/" + vList.size());
        boolean f = isFav(it);
        vFav.setText(f ? "♥ В избранном" : "♡ В избранное");
        vFav.setTextColor(f ? ACC : Color.WHITE);
        vControls.setVisibility(it.video ? View.VISIBLE : View.GONE);
    }

    void showPage(int dir) {
        stopVideo();
        stage.removeAllViews();
        Item it = curItem();
        if (it == null) { closeViewer(); return; }
        View page;
        if (it.video) {
            FrameLayout f = new FrameLayout(this);
            VideoView vv = new VideoView(this);
            curVideo = vv;
            if (it.vault) vv.setVideoPath(it.file.getAbsolutePath());
            else vv.setVideoURI(it.uri);
            vv.setOnPreparedListener(mp -> {
                vv.start();
                ui.removeCallbacks(ticker);
                ui.post(ticker);
            });
            vv.setOnCompletionListener(mp -> vPlay.setText("▶"));
            f.addView(vv, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
            View touch = new View(this);
            GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDown(MotionEvent e) { return true; }

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    toggleBars();
                    return true;
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    if (vv.isPlaying()) vv.pause(); else vv.start();
                    return true;
                }

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                    if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 600) {
                        swipe(vx < 0 ? 1 : -1);
                        return true;
                    }
                    return false;
                }
            });
            touch.setOnTouchListener((x, e) -> gd.onTouchEvent(e));
            f.addView(touch, new FrameLayout.LayoutParams(-1, -1));
            page = f;
        } else {
            ZoomImageView iv = new ZoomImageView(this);
            iv.listener = new ZoomImageView.Listener() {
                public void onSwipe(int d) { swipe(d); }
                public void onTap() { toggleBars(); }
            };
            Bitmap t = cache.get(it.key);
            if (t != null) iv.setImageBitmap(t);
            final int myPos = vPos;
            final Dialog myD = vd;
            pool.execute(() -> {
                Bitmap bm = full(it);
                ui.post(() -> { if (bm != null && vd == myD && vPos == myPos) iv.setImageBitmap(bm); });
            });
            page = iv;
        }
        stage.addView(page, new FrameLayout.LayoutParams(-1, -1));
        if (dir != 0 && stage.getWidth() > 0) {
            page.setTranslationX(dir * stage.getWidth() * 0.35f);
            page.setAlpha(0.3f);
            page.animate().translationX(0).alpha(1f).setDuration(180).start();
        }
        updateBars();
    }

    /** After an item disappears from the current list. */
    void afterRemoved(Item it) {
        if (vList != null && vd != null) {
            vList.remove(it);
            if (vList.isEmpty()) closeViewer();
            else {
                if (vPos >= vList.size()) vPos = vList.size() - 1;
                showPage(0);
            }
        }
    }

    void rename() {
        Item it = curItem();
        if (it == null) return;
        EditText e = field("Название", false);
        e.setText(name(it));
        e.setSelectAllOnFocus(true);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        dlg().setTitle("Изменить имя").setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (x, w) -> {
                    String s = e.getText().toString();
                    if (s.trim().isEmpty()) return;
                    if (isCode(s)) {
                        if (!it.vault) {
                            List<Item> l = new ArrayList<>();
                            l.add(it);
                            hideItems(l);
                        }
                        return;
                    }
                    prefs.edit().putString("n_" + it.key, s.trim()).apply();
                    updateBars();
                    render();
                }).show();
    }

    void addToAlbum() {
        Item it = curItem();
        if (it == null) return;
        JSONArray a = albums();
        String[] names = new String[a.length() + 1];
        for (int i = 0; i < a.length(); i++) {
            JSONObject al = a.optJSONObject(i);
            String n = al == null ? "Альбом" : al.optString("name");
            names[i] = (al != null && inAlbum(al, it.key) ? "✓ " : "") + n;
        }
        names[a.length()] = "＋ Новый альбом";
        dlg().setTitle("Альбом").setItems(names, (x, which) -> {
            if (which == names.length - 1) newAlbum(it);
            else { toggleInAlbum(which, it); render(); }
        }).show();
    }

    void shareCur() {
        Item it = curItem();
        if (it == null || it.vault) return;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(it.mime);
        i.putExtra(Intent.EXTRA_STREAM, it.uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i, "Отправить")); } catch (Exception e) { toast("Нет приложений"); }
    }

    // ================= hide / restore / delete =================

    void hideItems(List<Item> items) {
        toast("Скрываю…");
        loader.execute(() -> {
            List<JSONObject> metas = new ArrayList<>();
            List<File> files = new ArrayList<>();
            List<Item> ok = new ArrayList<>();
            File dir = vaultDir();
            ContentResolver cr = getContentResolver();
            for (Item it : items) {
                String ext = it.video ? ".mp4" : ".jpg";
                String m = it.mime == null ? "" : it.mime;
                if (m.contains("png")) ext = ".png";
                else if (m.contains("webp")) ext = ".webp";
                else if (m.contains("gif")) ext = ".gif";
                else if (m.contains("heic") || m.contains("heif")) ext = ".heic";
                else if (m.contains("3gp")) ext = ".3gp";
                else if (m.contains("webm")) ext = ".webm";
                else if (m.contains("matroska")) ext = ".mkv";
                String fname = UUID.randomUUID().toString().replace("-", "") + ext;
                File f = new File(dir, fname);
                boolean good = false;
                try (InputStream in = cr.openInputStream(it.uri); OutputStream out = new FileOutputStream(f)) {
                    if (in != null) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        good = true;
                    }
                } catch (Exception e) {
                    good = false;
                }
                if (!good || f.length() == 0) { f.delete(); continue; }
                try {
                    JSONObject o = new JSONObject();
                    o.put("file", fname);
                    o.put("name", name(it));
                    o.put("video", it.video);
                    o.put("mime", m);
                    o.put("date", it.date);
                    o.put("dur", it.dur);
                    metas.add(o);
                    files.add(f);
                    ok.add(it);
                } catch (Exception e) {
                    f.delete();
                }
            }
            ui.post(() -> {
                if (ok.isEmpty()) { toast("Не удалось скрыть"); return; }
                pendHide = ok;
                pendMeta = metas;
                pendFiles = files;
                deleteOriginals(ok, REQ_HIDE);
            });
        });
    }

    /** Ask the system to delete originals. Result arrives in onDeleteResult(req, success). */
    void deleteOriginals(List<Item> items, int req) {
        ContentResolver cr = getContentResolver();
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                List<Uri> uris = new ArrayList<>();
                for (Item it : items) uris.add(it.uri);
                PendingIntent pi = MediaStore.createDeleteRequest(cr, uris);
                startIntentSenderForResult(pi.getIntentSender(), req, null, 0, 0, 0);
            } catch (IntentSender.SendIntentException | RuntimeException e) {
                onDeleteResult(req, false);
            }
            return;
        }
        boolean ok = true;
        for (Item it : items) {
            try {
                if (cr.delete(it.uri, null, null) <= 0) ok = false;
            } catch (Exception e) {
                ok = false;
            }
        }
        onDeleteResult(req, ok);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_HIDE || req == REQ_DEL) onDeleteResult(req, res == RESULT_OK);
    }

    void onDeleteResult(int req, boolean ok) {
        if (req == REQ_HIDE) {
            List<Item> items = pendHide;
            List<JSONObject> metas = pendMeta;
            List<File> files = pendFiles;
            pendHide = null;
            pendMeta = null;
            pendFiles = null;
            if (items == null) return;
            if (!ok) {
                for (File f : files) f.delete();
                toast("Не скрыто: нужно разрешить удаление оригинала");
                return;
            }
            JSONArray a = vaultMeta();
            for (JSONObject o : metas) a.put(o);
            saveVaultMeta(a);
            for (Item it : items) {
                forgetKey(it.key);
                device.remove(it);
                afterRemoved(it);
            }
            loadVault();
            render();
        } else if (req == REQ_DEL) {
            List<Item> items = pendDelete;
            pendDelete = null;
            if (items == null || !ok) return;
            for (Item it : items) {
                forgetKey(it.key);
                device.remove(it);
                afterRemoved(it);
            }
            render();
        }
    }

    void deleteCur() {
        Item it = curItem();
        if (it == null) return;
        if (it.vault) {
            dlg().setTitle("Удалить навсегда?")
                    .setMessage("Файл будет удалён без возможности восстановления.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (x, w) -> {
                        removeFromVault(it, true);
                        afterRemoved(it);
                        render();
                    }).show();
            return;
        }
        List<Item> l = new ArrayList<>();
        l.add(it);
        if (Build.VERSION.SDK_INT >= 30) {
            pendDelete = l;
            deleteOriginals(l, REQ_DEL);
        } else {
            dlg().setTitle("Удалить?")
                    .setMessage("Файл будет удалён с телефона.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (x, w) -> {
                        pendDelete = l;
                        deleteOriginals(l, REQ_DEL);
                    }).show();
        }
    }

    void removeFromVault(Item it, boolean deleteFile) {
        JSONArray a = vaultMeta();
        JSONArray na = new JSONArray();
        String fname = it.file.getName();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !fname.equals(o.optString("file"))) na.put(o);
        }
        saveVaultMeta(na);
        if (deleteFile) it.file.delete();
        forgetKey(it.key);
        vault.remove(it);
    }

    void restoreCur() {
        Item it = curItem();
        if (it == null || !it.vault) return;
        final String nm = name(it);
        loader.execute(() -> {
            boolean ok = exportToPhone(it, nm);
            ui.post(() -> {
                if (!ok) { toast("Не удалось вернуть"); return; }
                removeFromVault(it, true);
                afterRemoved(it);
                render();
                toast("Возвращено в галерею");
                loadDevice();
            });
        });
    }

    boolean exportToPhone(Item it, String nm) {
        String ext = "";
        int dot = it.file.getName().lastIndexOf('.');
        if (dot > 0) ext = it.file.getName().substring(dot);
        String safe = nm.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (safe.isEmpty()) safe = "file";
        String display = safe + ext;
        String mime = it.mime == null || it.mime.isEmpty() ? (it.video ? "video/mp4" : "image/jpeg") : it.mime;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, display);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, (it.video ? "Movies" : "Pictures") + "/Галерея");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri table = it.video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                Uri u = cr.insert(table, v);
                if (u == null) return false;
                try (InputStream in = new FileInputStream(it.file); OutputStream out = cr.openOutputStream(u)) {
                    if (out == null) { cr.delete(u, null, null); return false; }
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(u, done, null, null);
                return true;
            }
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    it.video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES), "Галерея");
            if (!dir.exists() && !dir.mkdirs()) return false;
            File out = new File(dir, display);
            int i = 1;
            while (out.exists()) out = new File(dir, safe + " (" + (i++) + ")" + ext);
            try (InputStream in = new FileInputStream(it.file); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            MediaScannerConnection.scanFile(this, new String[]{out.getAbsolutePath()}, new String[]{mime}, null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
