package tj.gallery.secret;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.util.Size;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final int BG = 0xFF0F1012, CARD = 0xFF1B1C20, INK = 0xFFF2F2F0, MUTE = 0xFF9A9AA2,
            ACC = 0xFFFF5A4E, HID = 0xFF7C5CFF;
    static final int REQ = 7;

    static class Item {
        long id;
        boolean video;
        String file;
        Uri uri;

        String key() { return (video ? "v" : "i") + id; }
    }

    static class Holder {
        ImageView img;
        TextView name;
        TextView play;
        String key;
    }

    static class SquareFrame extends FrameLayout {
        SquareFrame(Context c) { super(c); }

        @Override
        protected void onMeasure(int w, int h) { super.onMeasure(w, w); }
    }

    SharedPreferences prefs;
    final List<Item> all = new ArrayList<>();
    final List<Item> shown = new ArrayList<>();
    boolean hiddenMode = false, goSettings = false;
    GridView grid;
    EditText search;
    TextView title, info, empty;
    LinearLayout searchRow, hidBar;
    Button permBtn;
    GridAdapter adapter;
    Dialog viewer;
    final ExecutorService loader = Executors.newSingleThreadExecutor();
    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final Handler ui = new Handler(Looper.getMainLooper());
    LruCache<String, Bitmap> cache;

    int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    Button btn(String t, int bg, int fg) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 12));
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinHeight(dp(46));
        b.setMinimumHeight(dp(46));
        b.setStateListAnimator(null);
        return b;
    }

    LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("g", MODE_PRIVATE);
        int mem = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8);
        cache = new LruCache<String, Bitmap>(mem) {
            @Override
            protected int sizeOf(String k, Bitmap v) { return v.getByteCount() / 1024; }
        };
        buildUi();
        if (!prefs.contains("code")) askCode(true);
        else checkPermAndLoad();
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), 0);

        title = new TextView(this);
        title.setText("Галерея");
        title.setTextColor(INK);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), dp(6), 0, dp(10));
        root.addView(title);

        searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        search = new EditText(this);
        search.setHint("Поиск по названию");
        search.setHintTextColor(MUTE);
        search.setTextColor(INK);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(round(CARD, 12));
        search.setPadding(dp(14), 0, dp(14), 0);
        searchRow.addView(search, lp(0, dp(48), 1));
        Button go = btn("Поиск", ACC, Color.WHITE);
        LinearLayout.LayoutParams gp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), 0);
        gp.leftMargin = dp(8);
        searchRow.addView(go, gp);
        root.addView(searchRow);

        hidBar = new LinearLayout(this);
        hidBar.setOrientation(LinearLayout.HORIZONTAL);
        hidBar.setGravity(Gravity.CENTER_VERTICAL);
        hidBar.setBackground(round(HID, 12));
        hidBar.setPadding(dp(14), dp(6), dp(6), dp(6));
        TextView ht = new TextView(this);
        ht.setText("Скрытые фото");
        ht.setTextColor(Color.WHITE);
        ht.setTextSize(15);
        ht.setTypeface(Typeface.DEFAULT_BOLD);
        hidBar.addView(ht, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button chg = btn("Сменить код", 0x33FFFFFF, Color.WHITE);
        hidBar.addView(chg, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40), 0));
        Button exit = btn("Выйти", 0x33FFFFFF, Color.WHITE);
        LinearLayout.LayoutParams ep = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40), 0);
        ep.leftMargin = dp(6);
        hidBar.addView(exit, ep);
        hidBar.setVisibility(View.GONE);
        root.addView(hidBar);

        info = new TextView(this);
        info.setTextColor(MUTE);
        info.setTextSize(13);
        info.setPadding(dp(4), dp(10), 0, dp(8));
        root.addView(info);

        FrameLayout content = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(3));
        grid.setVerticalSpacing(dp(3));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setPadding(0, 0, 0, dp(24));
        adapter = new GridAdapter();
        grid.setAdapter(adapter);
        content.addView(grid, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout emptyBox = new LinearLayout(this);
        emptyBox.setOrientation(LinearLayout.VERTICAL);
        emptyBox.setGravity(Gravity.CENTER);
        empty = new TextView(this);
        empty.setTextColor(MUTE);
        empty.setTextSize(16);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(24), 0, dp(24), dp(16));
        emptyBox.addView(empty);
        permBtn = btn("Дать доступ", ACC, Color.WHITE);
        permBtn.setVisibility(View.GONE);
        emptyBox.addView(permBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), 0));
        content.addView(emptyBox, new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, lp(-1, 0, 1));

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) { if (!hiddenMode) refresh(); }
        });
        search.setOnEditorActionListener((v, a, e) -> { doSearch(); return true; });
        go.setOnClickListener(v -> doSearch());
        exit.setOnClickListener(v -> { hiddenMode = false; refresh(); });
        chg.setOnClickListener(v -> askCode(false));
        permBtn.setOnClickListener(v -> {
            if (goSettings) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                startActivity(i);
            } else {
                requestPermissions(perms(), REQ);
            }
        });
        grid.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < shown.size()) openViewer(shown.get(pos));
        });
    }

    // ---------- code ----------

    static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("gal-v1:" + s.trim()).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.trim().hashCode());
        }
    }

    boolean isCode(String s) {
        if (s == null || s.trim().isEmpty()) return false;
        return hash(s).equals(prefs.getString("code", null));
    }

    EditText pass(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    void askCode(boolean first) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText a = pass(first ? "Код" : "Новый код");
        EditText b = pass("Повторите код");
        TextView err = new TextView(this);
        err.setTextColor(ACC);
        err.setPadding(0, dp(4), 0, 0);
        box.addView(a);
        box.addView(b);
        box.addView(err);
        AlertDialog.Builder bld = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(first ? "Придумайте код" : "Сменить код")
                .setView(box)
                .setPositiveButton("Сохранить", null);
        if (first) {
            bld.setMessage("Введите его дважды и запомните.");
            bld.setCancelable(false);
        } else {
            bld.setNegativeButton("Отмена", null);
        }
        AlertDialog d = bld.create();
        if (first) d.setCanceledOnTouchOutside(false);
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String s1 = a.getText().toString(), s2 = b.getText().toString();
            if (s1.trim().length() < 3) { err.setText("Минимум 3 символа"); return; }
            if (!s1.equals(s2)) { err.setText("Коды не совпадают"); return; }
            prefs.edit().putString("code", hash(s1)).apply();
            d.dismiss();
            if (first) checkPermAndLoad();
            else Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
        }));
        d.show();
    }

    void doSearch() {
        String v = search.getText().toString();
        hideKb();
        if (isCode(v)) {
            hiddenMode = true;
            search.setText("");
        }
        refresh();
    }

    void hideKb() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
        search.clearFocus();
    }

    // ---------- permissions & loading ----------

    String[] perms() {
        if (Build.VERSION.SDK_INT >= 33)
            return new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"};
        return new String[]{"android.permission.READ_EXTERNAL_STORAGE"};
    }

    boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    boolean hasPerm() {
        if (Build.VERSION.SDK_INT >= 33) {
            return granted("android.permission.READ_MEDIA_IMAGES") || granted("android.permission.READ_MEDIA_VIDEO")
                    || (Build.VERSION.SDK_INT >= 34 && granted("android.permission.READ_MEDIA_VISUAL_USER_SELECTED"));
        }
        return granted("android.permission.READ_EXTERNAL_STORAGE");
    }

    void checkPermAndLoad() {
        if (hasPerm()) load();
        else {
            showNoPerm();
            requestPermissions(perms(), REQ);
        }
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (hasPerm()) load();
        else {
            goSettings = !shouldShowRequestPermissionRationale(perms()[0]);
            showNoPerm();
        }
    }

    void showNoPerm() {
        shown.clear();
        adapter.notifyDataSetChanged();
        info.setText("");
        empty.setText("Разрешите доступ к фото и видео, чтобы галерея их показала.");
        empty.setVisibility(View.VISIBLE);
        permBtn.setText(goSettings ? "Открыть настройки" : "Дать доступ");
        permBtn.setVisibility(View.VISIBLE);
    }

    void load() {
        permBtn.setVisibility(View.GONE);
        loader.execute(() -> {
            List<Item> list = new ArrayList<>();
            Uri u = MediaStore.Files.getContentUri("external");
            String[] proj = {MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.Files.FileColumns.DATE_ADDED};
            String sel = MediaStore.Files.FileColumns.MEDIA_TYPE + "=? OR " + MediaStore.Files.FileColumns.MEDIA_TYPE + "=?";
            String[] args = {String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE),
                    String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)};
            try (Cursor c = getContentResolver().query(u, proj, sel, args,
                    MediaStore.Files.FileColumns.DATE_ADDED + " DESC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        Item it = new Item();
                        it.id = c.getLong(0);
                        it.file = c.getString(1);
                        if (it.file == null) it.file = "";
                        it.video = c.getInt(2) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
                        it.uri = ContentUris.withAppendedId(it.video
                                ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, it.id);
                        list.add(it);
                    }
                }
            } catch (Exception e) {
                // ignore
            }
            ui.post(() -> {
                all.clear();
                all.addAll(list);
                refresh();
            });
        });
    }

    String name(Item it) {
        String n = prefs.getString("n_" + it.key(), null);
        if (n != null) return n;
        int d = it.file.lastIndexOf('.');
        return d > 0 ? it.file.substring(0, d) : it.file;
    }

    boolean isHidden(Item it) { return prefs.getBoolean("h_" + it.key(), false); }

    void refresh() {
        if (!hasPerm()) { showNoPerm(); return; }
        String q = hiddenMode ? "" : search.getText().toString().trim().toLowerCase();
        shown.clear();
        int total = 0;
        for (Item it : all) {
            if (isHidden(it) != hiddenMode) continue;
            total++;
            if (q.isEmpty() || name(it).toLowerCase().contains(q)) shown.add(it);
        }
        adapter.notifyDataSetChanged();
        title.setText(hiddenMode ? "Скрытые" : "Галерея");
        searchRow.setVisibility(hiddenMode ? View.GONE : View.VISIBLE);
        hidBar.setVisibility(hiddenMode ? View.VISIBLE : View.GONE);
        if (hiddenMode) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        info.setText(total == 0 ? "" : (q.isEmpty() ? "Всего: " + total : "Найдено: " + shown.size()));
        permBtn.setVisibility(View.GONE);
        if (shown.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            if (hiddenMode) empty.setText("Здесь пока пусто.\nЧтобы скрыть фото, откройте его, нажмите «Изменить имя» и введите код.");
            else if (!q.isEmpty()) empty.setText("Ничего не найдено");
            else empty.setText("Фото и видео не найдены");
        } else {
            empty.setVisibility(View.GONE);
        }
    }

    // ---------- thumbnails ----------

    Bitmap thumb(Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 29)
                return getContentResolver().loadThumbnail(it.uri, new Size(320, 320), null);
            if (it.video)
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), it.id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            return MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), it.id,
                    MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Exception e) {
            return null;
        }
    }

    class GridAdapter extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int p) { return shown.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int pos, View cv, ViewGroup parent) {
            Holder h;
            if (cv == null) {
                SquareFrame f = new SquareFrame(MainActivity.this);
                f.setBackground(round(CARD, 6));
                f.setClipToOutline(true);
                h = new Holder();
                h.img = new ImageView(MainActivity.this);
                h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                f.addView(h.img, new FrameLayout.LayoutParams(-1, -1));
                h.name = new TextView(MainActivity.this);
                h.name.setTextColor(Color.WHITE);
                h.name.setTextSize(11);
                h.name.setSingleLine(true);
                h.name.setEllipsize(TextUtils.TruncateAt.END);
                h.name.setPadding(dp(6), dp(14), dp(6), dp(4));
                h.name.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{0x00000000, 0xAA000000}));
                f.addView(h.name, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
                h.play = new TextView(MainActivity.this);
                h.play.setText("▶");
                h.play.setTextColor(Color.WHITE);
                h.play.setTextSize(13);
                h.play.setShadowLayer(4, 0, 0, Color.BLACK);
                h.play.setPadding(dp(6), dp(4), dp(6), dp(4));
                f.addView(h.play, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
                f.setTag(h);
                cv = f;
            } else {
                h = (Holder) cv.getTag();
            }
            final Item it = shown.get(pos);
            final Holder fh = h;
            final String k = it.key();
            fh.key = k;
            fh.name.setText(name(it));
            fh.play.setVisibility(it.video ? View.VISIBLE : View.GONE);
            Bitmap bm = cache.get(k);
            if (bm != null) {
                fh.img.setImageBitmap(bm);
            } else {
                fh.img.setImageDrawable(null);
                pool.execute(() -> {
                    if (!k.equals(fh.key)) return;
                    Bitmap t = thumb(it);
                    if (t != null) cache.put(k, t);
                    ui.post(() -> { if (k.equals(fh.key) && t != null) fh.img.setImageBitmap(t); });
                });
            }
            return cv;
        }
    }

    // ---------- viewer ----------

    Bitmap full(Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), it.uri);
                return ImageDecoder.decodeBitmap(src, (dec, inf, s) -> {
                    int w = inf.getSize().getWidth(), hh = inf.getSize().getHeight();
                    int m = Math.max(w, hh);
                    if (m > 2048) {
                        float r = 2048f / m;
                        dec.setTargetSize(Math.max(1, Math.round(w * r)), Math.max(1, Math.round(hh * r)));
                    }
                });
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 2048) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
                return BitmapFactory.decodeStream(in, null, o2);
            }
        } catch (Exception e) {
            return thumb(it);
        } catch (OutOfMemoryError e) {
            return thumb(it);
        }
    }

    void openViewer(Item it) {
        Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        viewer = d;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackgroundColor(Color.BLACK);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(8), dp(12), dp(8));
        Button back = btn("←", 0x22FFFFFF, Color.WHITE);
        top.addView(back, lp(dp(48), dp(46), 0));
        TextView nm = new TextView(this);
        nm.setText(name(it));
        nm.setTextColor(Color.WHITE);
        nm.setTextSize(17);
        nm.setTypeface(Typeface.DEFAULT_BOLD);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        nm.setPadding(dp(12), 0, 0, 0);
        top.addView(nm, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        v.addView(top);

        FrameLayout media = new FrameLayout(this);
        VideoView vv = null;
        if (it.video) {
            vv = new VideoView(this);
            final VideoView fvv = vv;
            vv.setVideoURI(it.uri);
            vv.setOnPreparedListener(mp -> { mp.setLooping(true); fvv.start(); });
            vv.setOnTouchListener((x, e) -> {
                if (e.getAction() == android.view.MotionEvent.ACTION_UP) {
                    if (fvv.isPlaying()) fvv.pause(); else fvv.start();
                }
                return true;
            });
            media.addView(vv, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        } else {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            Bitmap t = cache.get(it.key());
            if (t != null) iv.setImageBitmap(t);
            media.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            pool.execute(() -> {
                Bitmap bm = full(it);
                ui.post(() -> { if (bm != null && viewer == d) iv.setImageBitmap(bm); });
            });
        }
        v.addView(media, lp(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(dp(12), dp(10), dp(12), dp(16));
        Button ren = btn("Изменить имя", 0x22FFFFFF, Color.WHITE);
        bottom.addView(ren, lp(0, dp(48), 1));
        if (hiddenMode) {
            Button un = btn("Вернуть в галерею", 0x22FFFFFF, Color.WHITE);
            LinearLayout.LayoutParams up = lp(0, dp(48), 1);
            up.leftMargin = dp(8);
            bottom.addView(un, up);
            un.setOnClickListener(x -> {
                prefs.edit().remove("h_" + it.key()).apply();
                d.dismiss();
                refresh();
                Toast.makeText(this, "Возвращено в галерею", Toast.LENGTH_SHORT).show();
            });
        }
        v.addView(bottom);

        back.setOnClickListener(x -> d.dismiss());
        ren.setOnClickListener(x -> rename(it, d, nm));
        final VideoView fv = vv;
        d.setOnDismissListener(x -> {
            if (fv != null) fv.stopPlayback();
            if (viewer == d) viewer = null;
        });
        d.setContentView(v);
        if (hiddenMode && d.getWindow() != null)
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        d.show();
    }

    void rename(Item it, Dialog d, TextView nm) {
        EditText e = new EditText(this);
        e.setText(name(it));
        e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        AlertDialog ad = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Изменить имя")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (x, w) -> {
                    String s = e.getText().toString();
                    if (s.trim().isEmpty()) return;
                    if (isCode(s)) {
                        if (!isHidden(it)) {
                            prefs.edit().putBoolean("h_" + it.key(), true).apply();
                            d.dismiss();
                            refresh();
                        }
                        return;
                    }
                    prefs.edit().putString("n_" + it.key(), s.trim()).apply();
                    nm.setText(s.trim());
                    refresh();
                })
                .create();
        ad.show();
    }

    // ---------- lifecycle ----------

    @Override
    protected void onRestart() {
        super.onRestart();
        if (hasPerm()) load();
        else showNoPerm();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (hiddenMode) {
            if (viewer != null) viewer.dismiss();
            hiddenMode = false;
            refresh();
        }
    }

    @Override
    public void onBackPressed() {
        if (hiddenMode) {
            hiddenMode = false;
            refresh();
            return;
        }
        super.onBackPressed();
    }
}
